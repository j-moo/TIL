학습 목표
- Django Form이 무엇인지 설명할 수 있다.
- Form을 통해 사용자 입력 데이터를 수집하고 처리할 수 있다.
- Form 클래스 정의 및 유효성 검사를 직접 수행할 수 있다.
- ModelForm을 활용하여 데이터베이스와 연동되는 입력 폼을 생성할 수 있다.
- Form과 ModelForm의 차이를 이해하고, 적절한 상황에 따라 선택하여 활용할 수 있다.

---

Django Form

---

HTML Form의 한계  

HTML 'form'  
- 지금까지 사용자로부터 데이터를 제출 받기위해 활용한 방법 그러나 비정상적 혹은 악의적인 요청을 필터링 할 수 없음

```
- 유효한 데이터인지에 대한 확인이 필요합니다.
```

---

유효성 검사란?  

유효성 검사
- 수집한 데이터가 정확하고 유효한지 확인하는 과정

```
- Django Form의 유효성 검사는 사용자가 입력한 데이터가 올바른 형식인지 자동을 점검하는 기능을 제공합니다.
- 예를 들어, 필수 입력 값이 비어 있거나 잘못된 이메일 형식을 입력하면 오류를 알려줍니다.
- 이 과정을 통해 서버에 잘못된 데이터가 저장되지 않도록 보호할 수 있습니다.
```

---

유효성 검사 구현의 어려움
- 유효성 검사를 구현하기 위해서는 입력 값, 형식, 중복, 범위, 보안 등 많은 것들을 고려해야 함
- 이런 과정과 기능을 직접 개발하는 것이 아닌 Djgnao가 제공하는 Form을 사용

---

Form Class

---

Django Form의 기능

Django Form
- 사용자 입력 데이터를 수집하고, 처리 및 유효성 검사를 수행하기 위한 도구

```
- 유효성 검사를 단순화하고 자동화 할 수 있는 기능을 제공합니다.
- 사용자가 잘못 입력한 데이터는 자동으로 오류로 처리되어 안전성을 높입니다.
- 개발자는 이를 통해 빠르고 일관된 입력 검증 기능을 구현할 수 있습니다.
```

Form Class 정의
- Form Class를 상속받아 내용과 제목에 대한 사용자 입력을 받는 ArticleForm을 정의하는 방법

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-23 233506.jpg>)

---

Form Class를 적용한 new logic
- view 함수 new 변경

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-23 233547.jpg>)  

- new 페이지에서 form 인스턴스 출력

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 162637.jpg>)  


- new 페이지에서 form 인스턴스 출력  

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 162717.jpg>)  

---

Form class가 대체하는 것

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 162754.jpg>)  

---

Widgets  
- HTML 'input' element의 표현 담당

```
- Djgno Form의 widgets은 각 필드가 HTML에서 어떻게 렌더링 될지를 결정합니다.
- 예를 들어, Textinput, Select, CheckboxInput 등 다양한 위젯 클래스를 사용해 입력 방식과 속성을 세부 조정할 수 있습니다.
```

> widgets : 폼 필드를 화면에 표시하는 HTML입력 요소를 정의하는 구성요소

---

widget 적용
- widget은 단숭히 input 요소의 속성 및 출력되는 부분을 변경하는 것

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163019.jpg>)

---

Djgno ModelForm  

---

Form vs ModelForm  

Form
- 사용장 입력 데이터를 DB에 저장하지 않을 때(ex. 검색, 로그인)

ModelForm
- 사용자 입력 데이터를 DB에 저장해야 할 때 (ex. 게시글 작성, 회원가입)

---

ModelForm 기능

---

ModelForm
- Model과 연결된 Form을 자동으로 생성해주는 기능을 제공

```
- ModelForm은 Form 클래스와 Model 클래스를 결합한 형태로, 모델 필드를 기반으로 입력 폼을 생성해줍니다.
- 데이터 수집과 저정 과정을 동시에 처리할 수 있도록 도와줍니다.
```

---

ModelForm class 정의
- 기존 ArticleForm 클래스 수정

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163322.jpg>)

---

Djgango ModelForm  

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163352.jpg>)

--

ModelForm class가 대체하는 것

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163426.jpg>)

---

Meta class

- ModelForm의 정보를 작성하는 곳

```
- Meta class는 ModelForm 내부에서 어떤 모델과 연결할지, 어떤 필드를 사용할지 등을 정의하는 설정 공간입니다.
- 폼의 동작 방식을 제어하는 핵심 역할을 합니다.
```

---

'fiels'및 'exclude'속성
- exclude 속성ㅇ르 사용하여 모델에서 포함하지 않도록 필드를 지정할 수도 있음

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163657.jpg>)

---

Meta class 주의사항
- Django에서 ModelForm에 대한 추가 정보나 속성을 작성하는 클래스 구조를 Meta 클래스로 작성 했을 뿐이며, 파이썬의 inner class와 같은 문법적인 관점으로 접근하지 말 것

---

ModelForm 적용

---

ModelForm을 작성한 create 로직

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163839.jpg>)

- 제목 input에 공백을 입력 후 제출 시 에러 메시지 출력 확인
  - 유효성 검사의 결과

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 163922.jpg>)

---

is_valid()
- 여러 유효성 검사를 실행하고, 데이터가 유효한지 여부를 Boolean으로 반환

---

공백 데이터가 유효하지 않은 이유와 에러메시지가 출력되는 과정
- 별도로 명시하지 않았지만 모델 필드에는 기본적으로 빈 값은 허용한지 않는 제약조건이 설정 되어있음
- 빈 값은 is_valid()에 의해 False로 평가되고 form 객체에는 그에 맞는 에러 메시지가 포함되어 다음 코드로 진행됨

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 164125.jpg>)

---

ModelForm을 적용 edit 로직

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 164157.jpg>)

---

ModelForm을 적용한 update 로직

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 164229.jpg>)

---

save 메서드   

개념  

save()
- 데이터베이스 객체를 만들고 저장하는 ModelForm의 인스턴스 메서드

```
- 폼 데이터가 유요한 경우, save() 메서드를 호출하면 모델 인스턴스를 생성하고 데이터베이스에 저장됩니다.
- instance 인자를 통해 새 객체 생성과 기존 객체 수정도 구분할 수 있습니다.
- 이 과정을 통해 코드 없이 손쉽게 DB연동이 가능합니다.
```

---

save() 메서드가 생성과 수정을 구분하는 법
- 키워드 인사 instance 여부를 통해 생성할 지, 수정할 지를 결정

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 165457.jpg>)

---

Django Form 정리

- 사용자로부터 데이터를 수집하고 처리하기 위한 강력하고 유연한 두고
- HTML form의 새성, 데이터 유효성 검사 및 처리를 쉽게 할 수 있도록 도움

---

HTTP 요청 다루기

---

view 함수 구조 변화

---

new & create view 함수간 공통점과 차이점

- 공통점
  - 데이터 생성을 구현하기 위함
- 차이점
  - new는 GET mothod 요청만을, create는 POST method 요청만을 처리

---

view 함수 구조화의 목적

- HTTP request method 차이점을 활용해 동일한 목적을 가지는 2개의 view 함수를 하나로 구조화

---

new & create 함수 결합

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 165840.jpg>)


![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 165902.jpg>)

---

새로운 create view 함수
- new 와 create view 함수의 공통점과 칭점을 기반으로 하나의 함수로 결합

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 165949.jpg>)

- 두 함수의 유일한 차이점이었던 request method에 따른 분기

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170033.jpg>)

- POST일 때는 과거 create 함수 구조였던 객체 생성 및 저장 로직 처리

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170117.jpg>)

- POST가 아닐 때는 과거 new함수에서 진행했던 form 인스턴스 생성

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170205.jpg>)

- context에 담기는 form은
  1. is_valid()를 통과하지 못해 에러메시지를 담은 form이거나
  2. else문을 통한 form 인스턴스

---

기존 new 관련 코드 수정
- 사용하지 않게 된 new url 제거

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170342.jpg>)

- new 관련 키워드를 create로 변경

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170412.jpg>)

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170445.jpg>)

---

request method에 따른 요청의 변화  

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170517.jpg>)

---

edit & update 함수 결합

---

새로운 update view 함수
- 기존 edit과 update view 함수 결합

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170613.jpg>)

---

기존 edit 관련 크드 수정

- 사용하지 않는 edit url 제거

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170644.jpg>)

- edit 관련 키워드를 update로 변경

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170736.jpg>)

---

ModelForm의 키워드 인자 구성

---

ModelForm 키워드 인자 data와 instance 살펴보기
- data는 첫번째에 위치한 키워드 인자이기 때문에 생략 가능
- instance는 9번째에 위치한 키워드 인자이기 때문에 생략할 수 없었음

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170905.jpg>)

---

Widgets 응용

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170934.jpg>)

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 170958.jpg>)

---

필드를 수동으로 렌더링

![alt text](<../assets/images/04_16_Django_FORM/화면 캡처 2026-04-25 171033.jpg>)